# Android 功耗发热分析关键词与正则模式

本文档详细说明了 `android-thermal-power-rca` Skill 在从日志中提取数据时所使用的关键词、正则表达式、单位换算规则和阈值定义。

## 1. 核心维度提取规则

### 1.1. 温度演进 (Thermal/virtual-sensor-skin)

- **关键词/正则**:
  - `virtual-sensor-skin temp:\s*(\d+)`
- **单位换算**:
  - 日志中的原始值是**毫度摄氏度 (mC)**。
  - Skill 会自动将其转换为**摄氏度 (°C)**。
  - **公式**: `°C = 原始值 / 1000`
  - **示例**: `45000` -> `45.0°C`
- **关键节点阈值**:
  - **温热**: ≥ 37°C
  - **烫手**: ≥ 45°C

### 1.2. 环境光与外部环境 (Sensors-hal)

- **关键词/正则**:
  - `ambient_light_event.*lux: (\d+\.?\d*)`
  - `light sensor new lux is (\d+)`
- **单位**:
  - **勒克斯 (lux)**
- **暴晒阈值**:
  - **室外环境**: > 10,000 lux
  - **烈日直射**: > 50,000 lux

### 1.3. 充放电与电池状态 (healthd/Battery)

- **关键词/正则**:
  - `healthd:.*battery l=(\d+).*t=(\d+\.?\d*)` (l=level, t=temperature)
  - `BatteryService: level:(\d+),.*temperature: (\d+)` (温度单位为 0.1°C)
  - `chargerType = (\w+)`
  - `plugged: \d+ -> (\d+)` (0 表示未插入)
- **单位说明**:
  - `BatteryService` 中的温度值需除以 10 得到摄氏度。

### 1.4. 整机放电功耗 (Teardown Power / PowerMonitor)

- **关键词/正则**:
  - `avgPower:\s*([\d\.-]+)mA`
  - `realCurrent now is ([\d\.-]+)`
  - `deep_doze=(\w+)`
  - `screen_off=(\w+)`
- **单位**:
  - **电流**: 毫安 (mA)
  - **累计功耗**: 毫安时 (mAh)，由脚本根据电流和时间间隔估算。

### 1.5. 前台应用与屏幕状态 (FrontPkg / PowerScene)

- **关键词/正则**:
  - `PowerScene:.*frontPkg: ([\w\.]+)`
  - `analyseAppCtrl: change, target=([\w\.]+)`
  - `screenOn:(\w+)`
  - `wakelock:(\w+)`

### 1.6. 底层负载与高耗电进程 (KTOP / CPU)

- **关键词/正则**:
  - `FEAT_MONITOR_KTOP.*sum/duration ratios: (.*)`
  - `CPU usage:.*(top.*)`
- **说明**: `FEAT_MONITOR_KTOP` 提供了更精确的进程/线程 CPU 占用率，是定位软件负载元凶的关键依据。

## 2. 主动异常挖掘规则

- **通信基带/网络**:
  - `signal strength`
  - `modem`, `radio`
  - `out of service` (用于判断是否频繁搜网)
- **硬件组件**:
  - `camera`, `gps`, `bluetooth`, `wifi` (确认高耗电硬件模块的活动状态)
- **内核异常**:
  - `kswapd0` (内存回收)
  - `kworker` (内核工作线程)
  - `watchdog` (系统假死/卡顿)
  - `OOM` (Out of Memory)
- **温控干预**:
  - `ThermalEngine: ACTION:`
  - `AiThermal: ACTION:` (用于判断系统是否已采取降温措施，以及措施是否及时有效)
