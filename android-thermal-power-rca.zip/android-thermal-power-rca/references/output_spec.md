# Skill 输出规范

本文档定义了 `android-thermal-power-rca` Skill 的输出文件（`metrics.json`, `timeline.json`, `report.md`）的结构和字段规范。

## 1. 结构化数据 (`outputs/metrics.json`)

该文件是一个 JSON 数组，包含了从日志中提取的所有原始数据点。

### 数据点对象结构

每个对象代表一个从日志中提取到的指标，结构如下：

```json
{
    "timestamp": "2024-05-08T10:20:30.123",
    "key": "skin_temp",
    "value": 45.0,
    "type": "float",
    "unit": "°C",
    "raw_line": "05-08 10:20:30.123  1234  5678 I virtual-sensor-skin temp: 45000",
    "source_file": "logcat_main.txt"
}
```

- **`timestamp`** (string): 事件发生的时间戳 (ISO 8601 格式)。
- **`key`** (string): 指标的唯一标识符（例如 `skin_temp`, `ambient_light_lux`）。
- **`value`** (any): 提取到的指标值。根据 `type` 字段，可以是 `float`, `string`, 或 `dict`。
- **`type`** (string): 值的类型 (`float`, `string`, `dict` 等)。
- **`unit`** (string, optional): 指标的单位（例如 `°C`, `lux`, `mA`）。
- **`raw_line`** (string): 匹配到的原始日志行内容。
- **`source_file`** (string): 该日志行所在的源文件名。

## 2. 时间线数据 (`outputs/timeline.json`)

该文件是一个 JSON 数组，用于存储 `build_timeline.py` 生成的关键事件时间线。

### 时间线事件对象结构

```json
{
    "timestamp": "2024-05-08T10:20:30.123",
    "event": "skin_temp",
    "description": "皮肤温度达到 45.0°C",
    "value": 45.0,
    "source_line": "05-08 10:20:30.123  1234  5678 I virtual-sensor-skin temp: 45000"
}
```

- **`timestamp`** (string): 事件发生的时间戳。
- **`event`** (string): 事件的类型，通常对应 `metrics.json` 中的 `key`。
- **`description`** (string): 对该关键事件的自然语言描述。
- **`value`** (any): 事件相关的数值。
- **`source_line`** (string): 触发该事件的原始日志行。

## 3. 分析报告 (`outputs/report.md`)

该文件是最终交付给用户的 Markdown 格式分析报告。其内容由 `render_report.py` 脚本结合 `assets/report_template.md` 模板生成。

### 报告结构模板占位符

在 `assets/report_template.md` 中，使用了以下占位符来注入动态内容：

- **`{{TIMELINE}}`**:
  - **替换内容**: 由 `timeline.json` 数据生成的 Markdown 表格，展示关键事件时间线。
- **`{{ANALYSIS_SECTIONS}}`**:
  - **替换内容**: 所有七个维度的单项分析内容。每个维度的分析都是一个独立的 H3 章节，包含数据展示和专业解读。
- **`{{ROOT_CAUSE_CORE}}`**:
  - **替换内容**: 一句话概括的核心根本原因结论。
- **`{{ROOT_CAUSE_FACTORS}}`**:
  - **替换内容**: 对多因素如何叠加导致问题的详细剖析。
- **`{{SUGGESTIONS}}`**:
  - **替换内容**: 如果定位到软件问题，此处会包含具体的软件优化策略和建议。
