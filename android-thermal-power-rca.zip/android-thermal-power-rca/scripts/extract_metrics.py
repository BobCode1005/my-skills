#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import json
import argparse
from datetime import datetime

# 定义关键词和正则表达式
# 每个 pattern 包含:
# - re: 正则表达式
# - key: 提取出的指标名称
# - type: 'float' 或 'string'
# - unit: 指标单位 (可选)
# - processor: 一个函数，用于对匹配结果进行后处理 (可选)
PATTERNS = [
    # 温度演进 (Thermal/virtual-sensor-skin)
    {
        "re": r"virtual-sensor-skin temp:\s*(\d+)",
        "key": "skin_temp",
        "type": "float",
        "unit": "°C",
        "processor": lambda x: float(x[0]) / 1000 if x else None
    },
    # 环境光与外部环境 (Sensors-hal)
    {
        "re": r"ambient_light_event.*lux: (\d+\.?\d*)",
        "key": "ambient_light_lux",
        "type": "float",
        "unit": "lux"
    },
    {
        "re": r"light sensor new lux is (\d+)",
        "key": "ambient_light_lux",
        "type": "float",
        "unit": "lux"
    },
    # 充放电与电池状态 (healthd/Battery)
    {
        "re": r"healthd:.*battery l=(\d+).*t=(\d+\.?\d*).*",
        "key": "battery_info",
        "type": "dict",
        "processor": lambda x: {"level": int(x[0]), "temperature": float(x[1])} if x else None
    },
    {
        "re": r"BatteryService: level:(\d+),.*temperature: (\d+)",
        "key": "battery_info",
        "type": "dict",
        "processor": lambda x: {"level": int(x[0]), "temperature": float(x[1])/10.0} if x else None
    },
    {
        "re": r"chargerType = (\w+)",
        "key": "charger_type",
        "type": "string"
    },
    {
        "re": r"plugged: \d+ -> (\d+)",
        "key": "plugged_state",
        "type": "string",
        "processor": lambda x: "plugged" if x and x[0] != '0' else "unplugged"
    },
    # 整机放电功耗 (Teardown Power / PowerMonitor)
    {
        "re": r"avgPower:\s*([\d\.-]+)mA",
        "key": "avg_power",
        "type": "float",
        "unit": "mA"
    },
    {
        "re": r"realCurrent now is ([\d\.-]+)",
        "key": "real_current",
        "type": "float",
        "unit": "mA"
    },
    {
        "re": r"deep_doze=(\w+)",
        "key": "deep_doze",
        "type": "string"
    },
    {
        "re": r"screen_off=(\w+)",
        "key": "screen_off",
        "type": "string"
    },
    # 前台应用与屏幕状态 (FrontPkg / PowerScene)
    {
        "re": r"PowerScene:.*frontPkg: ([\w\.]+)",
        "key": "front_pkg",
        "type": "string"
    },
    {
        "re": r"analyseAppCtrl: change, target=([\w\.]+)",
        "key": "front_pkg",
        "type": "string"
    },
    {
        "re": r"screenOn:(\w+)",
        "key": "screen_on",
        "type": "string"
    },
    {
        "re": r"wakelock:(\w+)",
        "key": "wakelock",
        "type": "string"
    },
    # 底层负载与高耗电进程 (KTOP / CPU)
    {
        "re": r"CPU usage:.*(top.*)",
        "key": "cpu_top_usage",
        "type": "string"
    },
    {
        "re": r"FEAT_MONITOR_KTOP.*sum/duration ratios: (.*)",
        "key": "ktop_ratios",
        "type": "string"
    },
    # 主动异常挖掘
    {
        "re": r"(signal strength.*)",
        "key": "signal_strength",
        "type": "string"
    },
    {
        "re": r"(out of service)",
        "key": "network_state",
        "type": "string"
    },
    {
        "re": r"(camera\s*|gps\s*|bluetooth\s*|wifi\s*)",
        "key": "hardware_usage",
        "type": "string"
    },
    {
        "re": r"(kswapd0|kworker|watchdog|OOM)",
        "key": "kernel_exception",
        "type": "string"
    },
    {
        "re": r"(ThermalEngine: ACTION:.*)",
        "key": "thermal_action",
        "type": "string"
    },
    {
        "re": r"(AiThermal: ACTION:.*)",
        "key": "ai_thermal_action",
        "type": "string"
    }
]

# 日志时间戳格式，会尝试多种格式进行匹配
TIMESTAMP_FORMATS = [
    "%m-%d %H:%M:%S.%f",
    "%Y-%m-%d %H:%M:%S.%f",
]

def parse_log_timestamp(timestamp_str):
    """解析日志行中的时间戳字符串"""
    for fmt in TIMESTAMP_FORMATS:
        try:
            # 假定年份是当前年份，如果格式不包含年份
            if "%Y" not in fmt:
                 dt_obj = datetime.strptime(f"{datetime.now().year}-{timestamp_str}", f"%Y-{fmt}")
            else:
                 dt_obj = datetime.strptime(timestamp_str, fmt)
            return dt_obj.isoformat()
        except ValueError:
            continue
    return None

def extract_metrics_from_line(line):
    """从单行日志中提取指标"""
    # 尝试匹配时间戳
    # 例如: "05-08 10:00:00.123  1234  5678 I ThermalEngine:"
    match = re.match(r"^(\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}\.\d{3})", line)
    if not match:
        return None, None

    timestamp_str = match.group(1)
    timestamp = parse_log_timestamp(timestamp_str)
    if not timestamp:
        return None, None
        
    content = line[match.end():]
    metrics = []

    for p in PATTERNS:
        try:
            matches = re.findall(p["re"], content, re.IGNORECASE)
            if not matches:
                continue

            for match_tuple in matches:
                # re.findall 返回的是元组或字符串列表
                value = match_tuple
                
                # 应用后处理器
                if p.get("processor"):
                    processed_value = p["processor"](value if isinstance(value, tuple) and len(value) > 1 else (value,))
                    if processed_value is None:
                        continue
                    value = processed_value
                else:
                    # 简化处理，如果findall返回的是元组，取第一个元素
                    if isinstance(value, tuple):
                        value = value[0]
                    
                    # 类型转换
                    if p["type"] == "float":
                        value = float(value)
                    elif p["type"] == "int":
                        value = int(value)

                metric_entry = {
                    "key": p["key"],
                    "value": value,
                    "type": p["type"],
                    "raw_line": line.strip()
                }
                if p.get("unit"):
                    metric_entry["unit"] = p["unit"]
                metrics.append(metric_entry)

        except Exception:
            # 忽略解析错误，继续处理下一个 pattern
            continue
            
    return timestamp, metrics


def process_log_files(log_dir):
    """处理指定目录下的所有日志文件"""
    all_metrics = []
    
    log_files = [f for f in os.listdir(log_dir) if os.path.isfile(os.path.join(log_dir, f)) and ('logcat' in f or 'dmesg' in f)]

    for log_file in log_files:
        file_path = os.path.join(log_dir, log_file)
        print(f"正在处理文件: {file_path}")
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    timestamp, metrics = extract_metrics_from_line(line)
                    if timestamp and metrics:
                        for metric in metrics:
                            all_metrics.append({
                                "timestamp": timestamp,
                                **metric,
                                "source_file": log_file
                            })
        except Exception as e:
            print(f"读取文件 {file_path} 时出错: {e}")

    return all_metrics


def main():
    parser = argparse.ArgumentParser(description="从 Android 日志文件中提取性能和功耗指标。")
    parser.add_argument("log_dir", help="包含 logcat 日志文件的目录。")
    parser.add_argument("-o", "--output", default="outputs/metrics.json", help="输出的 JSON 文件路径。")
    args = parser.parse_args()

    # 确保输出目录存在
    output_dir = os.path.dirname(args.output)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 提取指标
    metrics_data = process_log_files(args.log_dir)
    
    # 按时间戳排序
    metrics_data.sort(key=lambda x: x['timestamp'])

    # 保存到 JSON 文件
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(metrics_data, f, indent=4, ensure_ascii=False)

    print(f"指标提取完成，已保存到 {args.output}")


if __name__ == "__main__":
    main()
