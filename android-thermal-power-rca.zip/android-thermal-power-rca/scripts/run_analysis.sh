#!/bin/bash

# 这是一个端到端的分析脚本，用于自动化 Android 发热功耗分析流程。

set -e # 如果任何命令失败，立即退出脚本

# --- 配置 ---
# 获取脚本所在的目录，以便引用其他脚本
SCRIPT_DIR=$(dirname "$0")
# 项目根目录 (scripts/的上级目录)
PROJECT_ROOT_DIR=$(dirname "${SCRIPT_DIR}")
# Python 解释器
PYTHON_CMD="python3"

# --- 脚本主逻辑 ---

# 1. 检查输入参数
if [ -z "$1" ]; then
  echo "错误: 请提供日志文件所在的目录路径。"
  echo "用法: $0 <log_directory>"
  exit 1
fi

LOG_DIR="$1"
if [ ! -d "$LOG_DIR" ]; then
  echo "错误: 目录 '$LOG_DIR' 不存在。"
  exit 1
fi

# 2. 定义输出目录和文件路径
OUTPUT_DIR="${PROJECT_ROOT_DIR}/outputs"
METRICS_JSON="${OUTPUT_DIR}/metrics.json"
TIMELINE_JSON="${OUTPUT_DIR}/timeline.json"
REPORT_MD="${OUTPUT_DIR}/report.md"
TEMPLATE_MD="${PROJECT_ROOT_DIR}/assets/report_template.md"

# 创建输出目录
mkdir -p "$OUTPUT_DIR"
echo "输出目录 '${OUTPUT_DIR}' 已创建/确认。"

# 3. 执行分析流程
echo "
==================================================
  Android 功耗与发热分析 Skill - 开始执行
==================================================
"

# 步骤 1: 提取指标
echo "[步骤 1/3] 正在从日志中提取指标..."
${PYTHON_CMD} "${SCRIPT_DIR}/extract_metrics.py" "$LOG_DIR" -o "$METRICS_JSON"
if [ $? -ne 0 ]; then
    echo "错误: 提取指标失败。"
    exit 1
fi
echo "指标提取成功，产物: ${METRICS_JSON}"
echo "--------------------------------------------------"

# 步骤 2: 构建时间线
echo "[步骤 2/3] 正在构建关键事件时间线..."
${PYTHON_CMD} "${SCRIPT_DIR}/build_timeline.py" "$METRICS_JSON" -o "$TIMELINE_JSON"
if [ $? -ne 0 ]; then
    echo "错误: 构建时间线失败。"
    exit 1
fi
echo "时间线构建成功，产物: ${TIMELINE_JSON}"
echo "--------------------------------------------------"

# 步骤 3: 生成报告
echo "[步骤 3/3] 正在渲染最终分析报告..."
${PYTHON_CMD} "${SCRIPT_DIR}/render_report.py" "$METRICS_JSON" "$TIMELINE_JSON" --template "$TEMPLATE_MD" -o "$REPORT_MD"
if [ $? -ne 0 ]; then
    echo "错误: 生成报告失败。"
    exit 1
fi
echo "报告生成成功，产物: ${REPORT_MD}"
echo "--------------------------------------------------"


echo "
==================================================
  分析流程全部完成！
  最终报告请查看: ${REPORT_MD}
==================================================
"
