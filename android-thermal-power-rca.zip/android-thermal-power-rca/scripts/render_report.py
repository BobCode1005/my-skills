#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import argparse
import os
import re
from collections import defaultdict
from datetime import datetime

def read_json_file(file_path):
    """读取并解析 JSON 文件"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return None

def format_timeline(timeline_data):
    """格式化时间线为 Markdown 表格"""
    if not timeline_data:
        return "未能构建关键事件时间线。"

    md = "| 时间戳 | 事件描述 |\n"
    md += "|---|---|\n"
    for event in timeline_data:
        # 格式化时间，只显示 时:分:秒
        try:
            ts = datetime.fromisoformat(event['timestamp']).strftime('%H:%M:%S')
        except:
            ts = event['timestamp']
        md += f"| {ts} | {event['description']} |\n"
    return md

def analyze_dimension(metrics_data, key, title, normal_desc, abnormal_desc_func):
    """通用维度分析函数"""
    items = [m for m in metrics_data if m['key'] == key]
    if not items:
        return f"### {title}\n\n{normal_desc}，日志中未找到相关信息。\n"

    return f"### {title}\n\n{abnormal_desc_func(items)}\n"

# ==================================
# 各维度分析的具体实现
# ==================================

def analyze_thermal(items):
    temps = [m['value'] for m in items if isinstance(m['value'], (int, float))]
    if not temps:
        return "未提取到有效的温度数据。"
    
    start_temp = temps[0]
    peak_temp = max(temps)
    peak_time_item = max(items, key=lambda x: x.get('value', 0) if isinstance(x.get('value'), (int, float)) else 0)
    peak_time = datetime.fromisoformat(peak_time_item['timestamp']).strftime('%H:%M:%S')

    analysis = f"设备温度从 **{start_temp:.1f}°C** 开始，在 **{peak_time}** 达到峰值 **{peak_temp:.1f}°C**。\n\n"
    if peak_temp >= 45.0:
        analysis += "**结论**: 温度非常高，已达到烫手级别，是导致异常的核心因素。\n"
    elif peak_temp >= 37.0:
        analysis += "**结论**: 温度较高，体感温热，是重要的分析维度。\n"
    else:
        analysis += "**结论**: 温度在正常范围内，基本可以排除温度是主要矛盾。\n"
    return analysis

def analyze_ambient_light(items):
    lux_values = [m['value'] for m in items if isinstance(m['value'], (int, float))]
    if not lux_values:
        return "未提取到有效的光照数据。"
        
    max_lux = max(lux_values)
    avg_lux = sum(lux_values) / len(lux_values)
    
    analysis = f"最大光照度为 **{max_lux:.0f} lux**，平均光照度为 **{avg_lux:.0f} lux**。\n\n"
    if max_lux > 50000:
        analysis += "**结论**: 检测到极强的光照环境（>50,000 lux），设备可能处于**烈日暴晒**下，这是导致设备急剧升温的**关键外部因素**。\n"
    elif max_lux > 10000:
        analysis += "**结论**: 检测到室外光照环境（>10,000 lux），外部环境对设备升温有显著影响。\n"
    else:
        analysis += "**结论**: 光照度正常，可排除外部暴晒因素。\n"
    return analysis

def analyze_battery(items):
    charger_types = {m['value'] for m in items if m['key'] == 'charger_type'}
    plugged_states = {m['value'] for m in items if m['key'] == 'plugged_state'}
    
    analysis = ""
    if charger_types:
        analysis += f"检测到的充电类型: **{', '.join(charger_types)}**。\n"
    if plugged_states:
        analysis += f"检测到的充电状态: **{', '.join(plugged_states)}**。\n"
    
    battery_levels = [m['value']['level'] for m in items if m['key'] == 'battery_info' and 'level' in m['value']]
    if battery_levels:
        start_level = battery_levels[0]
        end_level = battery_levels[-1]
        analysis += f"电量从 **{start_level}%** 变化到 **{end_level}%**。\n"

    if not analysis:
        return "未提取到有效的电池或充电信息。"
        
    analysis += "\n**结论**: "
    if "plugged" in plugged_states or any("usb" in t.lower() or "ac" in t.lower() for t in charger_types):
        analysis += "设备在发热期间处于**充电状态**。充电本身会产生热量，叠加其他负载，会加剧发热。\n"
    else:
        analysis += "设备在发热期间未充电，发热完全由设备自身负载和外部环境导致。\n"
        
    return analysis

def analyze_power(items):
    currents = [m['value'] for m in items if m['key'] in ('avg_power', 'real_current') and isinstance(m['value'], (int, float))]
    if not currents:
        return "未提取到有效的电流数据。"

    avg_current = sum(currents) / len(currents)
    analysis = f"发热期间的平均放电电流约为 **{avg_current:.2f} mA**。\n\n"
    
    analysis += "**结论**: "
    if avg_current > 1000:
        analysis += "平均电流非常高（>1000mA），表明设备一直处于重度负载下，这是功耗和发热的主要内部原因。\n"
    elif avg_current > 500:
        analysis += "平均电流较高（>500mA），设备处于中高负载状态。\n"
    else:
        analysis += "平均电流在正常范围，整机功耗表现正常。\n"
    return analysis

def analyze_foreground_app(items):
    app_counts = defaultdict(int)
    for m in items:
        app_counts[m['value']] += 1
    
    if not app_counts:
        return "未提取到有效的前台应用信息。"
        
    # 找到出现次数最多的应用
    main_app = max(app_counts, key=app_counts.get)
    
    analysis = f"在发热期间，**`{main_app}`** 是最主要的前台应用。\n\n"
    analysis += "**结论**: 高负载可能与此应用的活动有关，需要结合 CPU 分析进一步确认。\n"
    return analysis

def analyze_cpu(items):
    ktop_items = [m for m in items if m['key'] == 'ktop_ratios']
    if not ktop_items:
        return "未提取到 FEAT_MONITOR_KTOP 日志，无法进行精确的进程负载分析。"
    
    # 简单的提取示例，实际可能需要更复杂的解析
    culprits = []
    for item in ktop_items:
        # "value": "99% cpuacct/bg_non_interactive"
        match = re.search(r'(\d+)%\s+([\w/.-]+)', item['value'])
        if match:
            usage = int(match.group(1))
            process = match.group(2)
            if usage > 30: # 假设阈值为 30%
                culprits.append(f"`{process}` (占用 **{usage}%**)")
    
    if not culprits:
        return "KTOP 日志中未发现 CPU 占用率持续过高的进程 (>30%)。"

    analysis = "通过 KTOP 日志分析，发现以下进程/线程存在高 CPU 占用：\n"
    analysis += "- " + "\n- ".join(list(set(culprits))) + "\n\n"
    analysis += "**结论**: 上述进程是主要的 CPU 负载来源，是导致设备发热的**核心软件原因**。\n"
    return analysis

def analyze_other_factors(items):
    events = defaultdict(list)
    for item in items:
        events[item['key']].append(item['value'])
        
    if not events:
        return "未发现其他明显的硬件或内核异常。"

    analysis = ""
    if events['signal_strength'] or events['network_state']:
        analysis += "- **通信/网络**: 检测到与信号强度或网络服务相关的日志，可能存在频繁搜网等高功耗行为。\n"
    if events['hardware_usage']:
        used_hw = {val for sublist in events['hardware_usage'] for val in re.findall(r"(camera|gps|bluetooth|wifi)", sublist)}
        if used_hw:
            analysis += f"- **硬件使用**: 日志显示 **{', '.join(used_hw)}** 等硬件模块在发热期间被激活，可能增加了功耗。\n"
    if events['kernel_exception']:
        exceptions = set(events['kernel_exception'])
        analysis += f"- **内核异常**: 发现 **{', '.join(exceptions)}** 等内核层面的异常事件，可能导致底层负载过高。\n"
    if events['thermal_action'] or events['ai_thermal_action']:
        analysis += "- **温控干预**: 系统温控策略已被触发，表明系统已识别到高温并尝试进行干预（如降频、限流）。\n"
        
    if not analysis:
        return "未发现其他明显的硬件或内核异常。"
        
    return f"综合分析，还发现以下潜在影响因素：\n{analysis}"


def generate_root_cause(all_analyses):
    """根据各维度分析结果，综合生成根本原因"""
    # 这是一个简化的逻辑，实际场景可能需要更复杂的规则引擎
    causes = []
    
    if "烈日暴晒" in all_analyses["环境光"]:
        causes.append("外部环境恶劣（烈日暴晒）")
    if "充电状态" in all_analyses["充放电与电池"]:
        causes.append("设备处于充电状态")
    if "核心软件原因" in all_analyses["底层负载"]:
        causes.append("特定应用/进程高 CPU 负载")
    if "平均电流非常高" in all_analyses["整机功耗"]:
        causes.append("整机持续处于高功耗状态")
        
    if not causes:
        if "温度非常高" in all_analyses["温度"]:
            return "**核心结论**: 设备严重发热，但从现有日志未能定位到单一明确根因，可能由多因素耦合导致或关键日志缺失。", ""
        else:
            return "**核心结论**: 设备温度和功耗基本正常，未见明显异常。", ""

    core_conclusion = f"**核心结论**: 本次发热问题主要由 **{' + '.join(causes)}** 复合导致。"
    
    factors_analysis = "**因素叠加剖析**: "
    details = []
    if "烈日暴晒" in all_analyses["环境光"]:
        details.append("设备在高温户外环境下使用，环境热量输入是基础。")
    if "核心软件原因" in all_analyses["底层负载"]:
        details.append("后台或前台有高负载应用持续运行，产生大量计算热。")
    if "充电状态" in all_analyses["充放电与电池"]:
        details.append("同时进行充电，充电模块本身的热量与设备运行热量叠加。")
    
    factors_analysis += " ".join(details)
    if not details:
        factors_analysis += "从日志分析，主要发热源为 " + causes[0] + "。"
        
    return core_conclusion, factors_analysis

def generate_suggestions(all_analyses):
    if "核心软件原因" in all_analyses["底层负载"]:
        return """
### 软件优化策略 (Key Suggestion)

针对日志中发现的高 CPU 占用进程，建议：
1.  **代码审查**: 对相关的模块进行 Code Review，重点排查是否存在死循环、频繁轮询、计算密集型任务未优化等问题。
2.  **后台行为**: 检查应用在后台时的行为，确保遵循 Android 的后台限制，避免不必要的唤醒和计算。
3.  **依赖库**: 检查所使用的第三方库是否存在已知的性能问题。
"""
    return "### 软件优化策略 (Key Suggestion)\n\n未定位到明确的软件性能问题，建议关注硬件使用和外部环境。\n"


def main():
    parser = argparse.ArgumentParser(description="根据提取的指标和时间线，渲染最终的分析报告。")
    parser.add_argument("metrics_path", help="输入的 metrics.json 文件路径。")
    parser.add_argument("timeline_path", help="输入的时间线 timeline.json 文件路径。")
    parser.add_argument("--template", default="assets/report_template.md", help="报告模板文件路径。")
    parser.add_argument("-o", "--output", default="outputs/report.md", help="输出的报告 Markdown 文件路径。")
    args = parser.parse_args()

    metrics_data = read_json_file(args.metrics_path)
    timeline_data = read_json_file(args.timeline_path)

    if metrics_data is None or timeline_data is None:
        print("错误: 无法读取 metrics.json 或 timeline.json。")
        return

    try:
        with open(args.template, 'r', encoding='utf-8') as f:
            template_content = f.read()
    except FileNotFoundError:
        print(f"错误: 找不到模板文件 {args.template}。")
        return

    # 1. 格式化时间线
    timeline_md = format_timeline(timeline_data)

    # 2. 各维度单项分析
    all_analyses = {
        "温度": analyze_dimension(metrics_data, 'skin_temp', "温度演进 (Thermal)", "温度表现正常", analyze_thermal),
        "环境光": analyze_dimension(metrics_data, 'ambient_light_lux', "环境光与外部环境 (Sensors-hal)", "光照环境正常", analyze_ambient_light),
        "充放电与电池": analyze_dimension(metrics_data, 'charger_type', "充放电与电池状态 (Battery)", "电池状态正常", lambda items: analyze_battery(metrics_data)),
        "整机功耗": analyze_dimension(metrics_data, 'avg_power', "整机放电功耗 (Power)", "整机功耗正常", lambda items: analyze_power(metrics_data)),
        "前台应用": analyze_dimension(metrics_data, 'front_pkg', "前台应用与屏幕状态", "未发现明确的长时间前台应用", analyze_foreground_app),
        "底层负载": analyze_dimension(metrics_data, 'ktop_ratios', "底层负载与高耗电进程 (CPU)", "CPU 负载正常", lambda items: analyze_cpu(metrics_data)),
        "其他因素": analyze_dimension(metrics_data, 'signal_strength', "其他发热强相关信息", "未发现其他异常", lambda items: analyze_other_factors(metrics_data))
    }
    
    analysis_md = "\n\n".join(all_analyses.values())

    # 3. 生成根因和建议
    root_cause_core, root_cause_factors = generate_root_cause(all_analyses)
    suggestions_md = generate_suggestions(all_analyses)

    # 4. 替换模板内容
    report_content = template_content.replace("{{TIMELINE}}", timeline_md)
    report_content = report_content.replace("{{ANALYSIS_SECTIONS}}", analysis_md)
    report_content = report_content.replace("{{ROOT_CAUSE_CORE}}", root_cause_core)
    report_content = report_content.replace("{{ROOT_CAUSE_FACTORS}}", root_cause_factors)
    report_content = report_content.replace("{{SUGGESTIONS}}", suggestions_md)

    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(report_content)
        
    print(f"报告生成完成，已保存到 {args.output}")

if __name__ == "__main__":
    main()
