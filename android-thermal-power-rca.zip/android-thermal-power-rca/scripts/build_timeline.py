#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import argparse
import os

# 定义关键事件的判断逻辑
# "key" 是在 metrics.json 中的指标key
# "condition" 是一个 lambda 函数，用于判断是否是关键事件
# "description" 是事件的描述模板
CRITICAL_EVENT_RULES = [
    {
        "key": "skin_temp",
        "condition": lambda v, prev_v: prev_v is None or (v >= 37 and (prev_v < 37)) or (v >= 45 and (prev_v < 45)),
        "description": "皮肤温度达到 {value:.1f}°C"
    },
    {
        "key": "ambient_light_lux",
        "condition": lambda v, prev_v: (v > 10000 and (prev_v is None or prev_v <= 10000)) or \
                                      (v > 50000 and (prev_v is None or prev_v <= 50000)),
        "description": "环境光照度达到 {value} lux，可能在户外"
    },
    {
        "key": "charger_type",
        "condition": lambda v, prev_v: v != prev_v,
        "description": "充电类型变为: {value}"
    },
    {
        "key": "plugged_state",
        "condition": lambda v, prev_v: v != prev_v,
        "description": "充电状态变为: {value}"
    },
    {
        "key": "front_pkg",
        "condition": lambda v, prev_v: v != prev_v,
        "description": "前台应用切换为: {value}"
    },
    {
        "key": "screen_on",
        "condition": lambda v, prev_v: v != prev_v,
        "description": "屏幕状态变为: {value}"
    },
    {
        "key": "thermal_action",
        "condition": lambda v, prev_v: True,
        "description": "温控策略触发: {value}"
    },
    {
        "key": "ai_thermal_action",
        "condition": lambda v, prev_v: True,
        "description": "AI温控策略触发: {value}"
    },
    {
        "key": "kernel_exception",
        "condition": lambda v, prev_v: True,
        "description": "内核出现异常事件: {value}"
    }
]

def build_timeline(metrics_path):
    """根据提取的指标构建时间线"""
    try:
        with open(metrics_path, 'r', encoding='utf-8') as f:
            metrics = json.load(f)
    except FileNotFoundError:
        print(f"错误: 找不到 metrics 文件 {metrics_path}")
        return []
    except json.JSONDecodeError:
        print(f"错误: 解析 metrics 文件 {metrics_path} 失败")
        return []

    timeline = []
    # 用于跟踪每个 key 的上一个值
    last_values = {}

    # 首先记录初始状态
    initial_states = {}
    for metric in metrics:
        key = metric["key"]
        if key not in initial_states:
            initial_states[key] = metric["value"]
    
    # 将初始状态添加到时间线（可选，如果需要的话）
    # ...

    for metric in metrics:
        key = metric["key"]
        value = metric["value"]
        timestamp = metric["timestamp"]
        
        # 获取该 key 的上一个值
        prev_value = last_values.get(key)

        for rule in CRITICAL_EVENT_RULES:
            if rule["key"] == key:
                if rule["condition"](value, prev_value):
                    description = rule["description"].format(value=value)
                    timeline.append({
                        "timestamp": timestamp,
                        "event": key,
                        "description": description,
                        "value": value,
                        "source_line": metric.get("raw_line", "")
                    })
        
        # 更新该 key 的值
        last_values[key] = value

    # 按时间戳排序
    timeline.sort(key=lambda x: x['timestamp'])

    return timeline

def main():
    parser = argparse.ArgumentParser(description="根据提取的指标构建关键事件时间线。")
    parser.add_argument("metrics_path", help="输入的 metrics.json 文件路径。")
    parser.add_argument("-o", "--output", default="outputs/timeline.json", help="输出的时间线 JSON 文件路径。")
    args = parser.parse_args()

    # 确保输出目录存在
    output_dir = os.path.dirname(args.output)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    timeline_data = build_timeline(args.metrics_path)

    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(timeline_data, f, indent=4, ensure_ascii=False)

    print(f"时间线构建完成，已保存到 {args.output}")


if __name__ == "__main__":
    main()
