# Android 功耗与发热问题分析报告

## 1. 关键指标时间线 (Timeline)

下表按时间顺序展示了本次发热事件中的关键节点，帮助还原问题发生的过程。

{{TIMELINE}}

## 2. 各维度异常单项分析

本章节针对温度、环境、电源、负载等七个核心维度，逐一进行深度剖析。

{{ANALYSIS_SECTIONS}}

## 3. 结构化的根本原因结论 (Root Cause)

{{ROOT_CAUSE_CORE}}

{{ROOT_CAUSE_FACTORS}}

## 4. 软件优化策略 (Key Suggestion)

{{SUGGESTIONS}}
